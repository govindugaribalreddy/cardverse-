﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using Unity.Collections;
using Unity.Netcode;
using Unity.Networking.Transport;
using Unity.Networking.Transport.Relay;
using Unity.Services.Authentication;
using Unity.Services.Core;
using Unity.Services.Relay;
using Unity.Services.Relay.Models;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Linq;
using NetworkEvent = Unity.Networking.Transport.NetworkEvent;

public class HostManager : NetworkBehaviour
{
    public static HostManager Instance { get; private set; }

    public TextMeshProUGUI status;
    public TextMeshProUGUI joinCodeText;
    public TextMeshProUGUI roomName;
    public Button nextButton;
    public Button startButton;
    public Button exitButton;

    public GameObject cardPrefab; // Assign in the inspector
    public Transform cardsParent; // Assign in the inspector


    private string message = "";
    private string roomOwner = "";
    private string username = "";
    private string joincode = "";
    private int maxConnections = 5;
    private int clientID = 0;

    NetworkDriver hostDriver;
    NativeList<NetworkConnection> serverConnections;

    GameSettings Settings = new GameSettings();
    DataHelper Helper = new DataHelper();
    TurnManager TurnManager = new TurnManager();
    TransportHelper Transport = new TransportHelper();
    PlayerManager PlayerManager;
    RoomManager RoomManager;

    #region Initialize Relay
    public void Start()
    {
        InitialSetup();
    }

    public void InitialSetup()
    {
        nextButton.interactable = false;
        status.text = "";
        joinCodeText.text = "";
        roomName.text = "";
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }
        InitialSetup();
    }

    public async Task Authenticate()
    {
        PlayerManager = GameObject.FindObjectOfType<PlayerManager>();
        RoomManager = GameObject.FindObjectOfType<RoomManager>();

        await UnityServices.InitializeAsync();

        AuthenticationService.Instance.SignedIn += () =>
        {
            Debug.Log("Signed In " + AuthenticationService.Instance.PlayerId);
        };

        await AuthenticationService.Instance.SignInAnonymouslyAsync();

        NetworkManager.Singleton.OnClientConnectedCallback += (clientId) =>
        {
            clientID = int.Parse(clientId.ToString());
            Debug.Log("Client with ID: " + clientId + " has joined");
        };
        await SetupHost();
    }

    public async Task SetupHost()
    {
        try
        {
            Settings = JsonUtility.FromJson<GameSettings>(PlayerPrefs.GetString("Settings"));
            maxConnections = Settings.MaxPlayers - 1;
            TurnManager.SetDirection(Settings.CardRotations);
            // Request a new allocation from the Relay service
            Allocation allocation = await RelayService.Instance.CreateAllocationAsync(maxConnections);

            // Get a join code for the newly allocated server that clients can use to join
            this.joincode = await RelayService.Instance.GetJoinCodeAsync(allocation.AllocationId);

            joinCodeText.text = "Join Code: " + joincode;
            message = username + " have created the room";
            roomOwner = username + "'s Room";
            status.text = message;
            roomName.text = roomOwner;

            var relayServerData = new RelayServerData(allocation, "udp");
            
            // Create NetworkSettings using the Relay server data.
            var settings = new NetworkSettings();
            settings.WithRelayParameters(ref relayServerData);

            // Create the Host's NetworkDriver from the NetworkSettings.
            hostDriver = NetworkDriver.Create(settings);

            // Bind to the Relay server.
            if (hostDriver.Bind(NetworkEndPoint.AnyIpv4) != 0)
            {
                Debug.LogError("Host client failed to bind");
            }
            else
            {
                if (hostDriver.Listen() != 0)
                {
                    Debug.LogError("Host client failed to listen");
                }
                else
                {
                    Debug.Log("Host client bound to Relay server");
                }

            }

            serverConnections = new NativeList<NetworkConnection>(maxConnections, Allocator.Persistent);
            TurnManager.AddPlayer(username); //adding host as first player
            PlayerManager.ArrangePlayers(maxConnections + 1, clientID);
            PlayerManager.SetPlayerActive(clientID);
            PlayerManager.SetUsername(clientID, username);
            int deckCount = PlayerPrefs.GetInt("DecksCount", 1);  // Assuming this is where you set your deck count
            StartCoroutine(WaitForClientsAndBroadcast(deckCount));

            var deckDisplayManager = FindObjectOfType<DeckDisplayManager>();
            if (deckDisplayManager != null)
            {
                deckDisplayManager.DisplayDecks(deckCount);
            }

        }
        catch (RelayServiceException e)
        {
            RoomManager.SendAlert("Error", "An unexpected error occurred, please try again later.\n" + e.Reason);
        }
    }

 
    public override void OnDestroy()
    {
        hostDriver.Dispose();
        serverConnections.Dispose();
    }

    public void SetData(string username, string joincode, GameSettings settings)
    {
        this.username = username;
        this.joincode = joincode;
        this.Settings = settings;
    }

    #endregion

    #region Send Message
    public void OnHostSendMessage(string message, string type)
    {
        if (serverConnections.Length == 0)
        {
            Debug.LogError("No players connected to send messages to.");
            return;
        }
        try
        {
            Transport.OnHostSendMessage(hostDriver, serverConnections, message, type);
        }
        catch (Exception e)
        {
            RoomManager.SendAlert("Error", "An unexpected error occurred, please try again later.\n" + e.Message);
        }
    }

    //public void OnHostSendMessageToClient(string message, string type, int clientId)
    //{
    //    if (serverConnections.Length == 0)
    //    {
    //        Debug.LogError("No players connected to send messages to.");
    //        return;
    //    }
    //    try
    //    {
    //        Transport.OnHostSendMessageToClient(hostDriver, serverConnections[clientID], message, type, clientID);
    //    }
    //    catch (Exception e)
    //    {
    //        RoomManager.SendAlert("Error", "An unexpected error occurred, please try again later.\n" + e.Message);
    //    }
    //}
    #endregion

    #region Update
    void Update()
    {
        // Skip update logic if the Host is not yet bound.
        if (!hostDriver.IsCreated || !hostDriver.Bound)
        {
            return;
        }

        // This keeps the binding to the Relay server alive, preventing it from timing out due to inactivity.
        hostDriver.ScheduleUpdate().Complete();

        Transport.CleanHostConnections(serverConnections);

        // Accept incoming client connections.
        NetworkConnection incomingConnection;
        while ((incomingConnection = hostDriver.Accept()) != default(NetworkConnection))
        {
            // Adds the requesting Player to the serverConnections list.
            // This also sends a Connect event back the requesting Player,
            // as a means of acknowledging acceptance.
            Debug.Log("Accepted an incoming connection.");
            serverConnections.Add(incomingConnection);
        }

        // Process events from all connections.
        for (int i = 0; i < serverConnections.Length; i++)
        {
            Assert.IsTrue(serverConnections[i].IsCreated);

            // Resolve event queue.
            NetworkEvent.Type eventType;
            while ((eventType = hostDriver.PopEventForConnection(serverConnections[i], out var stream)) != NetworkEvent.Type.Empty)
            {
                switch (eventType)
                {
                    // Handle Relay events.
                    case NetworkEvent.Type.Data:
                        HandleHostMessage(stream);
                        break;

                    // Handle Disconnect events.
                    case NetworkEvent.Type.Disconnect:
                        Debug.Log("Server received disconnect from client");
                        SendExitNotice(true);
                        serverConnections[i] = default(NetworkConnection);
                        break;
                }
            }
        }
    }
    #endregion
    // Coroutine to disconnect clients after a delay
    private IEnumerator DisconnectClients()
    {
        yield return new WaitForSeconds(2f); // Wait for 2 seconds

        // Disconnect all clients
        foreach (var connection in serverConnections)
        {
            hostDriver.Disconnect(connection);
        }
    }

    void HandleHostMessage(DataStreamReader stream)
    {
        NetworkData receivedData = Helper.TransformDataToObject(stream);

        Debug.Log($"Server received msg: {receivedData.value}");

        if (receivedData.type == "player-join")
        {
            string joinedUsername = receivedData.value;
            string stat = joinedUsername + " joined the room";
            status.text = stat;
            //syncing players
            TurnManager.AddPlayer(joinedUsername);
            OnHostSendMessage((TurnManager.playerOrder.Count - 1).ToString(), "clientID");
            OnHostSendMessage(roomOwner, "room-info");
            OnHostSendMessage(stat, "status");
            OnHostSendMessage((maxConnections+1).ToString(), "player-manager-arrange");

            //syncing players
            SyncPlayers();
            if (TurnManager.GetCount() == maxConnections + 1)
            {
                startButton.gameObject.SetActive(true);
            }
            Debug.Log("Added Client at position" + TurnManager.GetPlayerPosition(receivedData.value));
        }

        else if (receivedData.type == "status")
        {
            status.text = receivedData.value;
            OnHostSendMessage(receivedData.value, "status");

        }

        else if (receivedData.type == "made-move")
        {
            //finding which player made move
            int position = TurnManager.GetPlayerPosition(receivedData.value);

            //ending that player turn (making its hover background as white)
            string stat = receivedData.value + " made move";
            status.text = stat;
            OnHostSendMessage(stat, "status");
            PlayerManager.EndTurn(position);

            //Saying to end the player turn to all clients
            OnHostSendMessage(position.ToString(), "player-manager-current-end");

            //finding next player
            TurnManager.NextTurn();
            string currentUser = TurnManager.GetCurrentPlayer();
            position = TurnManager.GetPlayerPosition(currentUser);

            //Starting its turn (making its hover backgroudn as green)
            PlayerManager.StartTurn(position);

            //Saying to start this player turn to all clients
            OnHostSendMessage(position.ToString(), "player-manager-current-start");
            
            if (currentUser == username)
            {
                nextButton.interactable = true;
                Debug.Log("its your turn now");
            }
            else
            {
                OnHostSendMessage(currentUser, "change-turn");
            }
        }
    }

    public void HandleHostTurn()
    {
        PlayerManager.EndTurn(clientID);
        OnHostSendMessage(clientID.ToString(), "player-manager-current-end");
        TurnManager.NextTurn();
        string stat = username + " made move";
        status.text = stat;
        OnHostSendMessage(stat, "status");

        string currentUser = TurnManager.GetCurrentPlayer();
        int position = TurnManager.GetPlayerPosition(currentUser);
        PlayerManager.StartTurn(position);
        OnHostSendMessage(position.ToString(), "player-manager-current-start");
        OnHostSendMessage(currentUser, "change-turn");
    }

    public void SyncPlayers()
    {
        string jsonString = "";
        foreach (KeyValuePair<string, int> Player in TurnManager.playerOrder)
        {
            string client = "{\"username\":\"" + Player.Key + "\",\"clientId\":" + Player.Value + "}";
            jsonString += client + ";";

            PlayerManager.SetUsername(Player.Value, Player.Key);
            PlayerManager.SetPlayerActive(Player.Value);
        }
        jsonString = jsonString.TrimEnd(';');
        OnHostSendMessage(jsonString, "player-manager-sync");
    }

    public void StartGame()
    {
        startButton.gameObject.SetActive(false);
        OnHostSendMessage("Host started the Game", "status");
        nextButton.interactable = true;
        PlayerManager.StartTurn(clientID);
        OnHostSendMessage(clientID.ToString(), "player-manager-current-start");
    }

    public void SendExitNotice(bool fromClient)
    {
        if (fromClient)
        {
            OnHostSendMessage("1", "exit");
            RoomManager.SendAlert("Game Over", "One Player have left the room\nGame Over!");
            exitButton.gameObject.SetActive(false);
        }
        else
        {
            if (serverConnections.Length > 0)
            {
                OnHostSendMessage("0", "exit");
            }
            ExitGame();
        }
    }

    public void ExitGame()
    {
        // Clean up network resources
        // Load the main scene
        //destroy everything
        SceneManager.LoadScene("MainScene");
    }

    private IEnumerator WaitForClientsAndBroadcast(int count)
    {
        while (serverConnections.Length == 0)
        {
            yield return new WaitForSeconds(60); // Wait for 15 second before checking again
            Debug.Log("Waiting for clients to connect...");
        }
        BroadcastDeckCount(count);
    }

    private void BroadcastDeckCount(int count)
    {
        //string message = JsonUtility.ToJson(new NetworkData { value = count.ToString() });
        string message = count.ToString();
        OnHostSendMessage(message, "update-deck-count");
    }

    public void DealCardsToPlayers(List<Card> deck)
    {
        // Shuffle and deal cards as previously defined...
        foreach (var player in TurnManager.playerOrder)
        {
            if (deck.Count >= Settings.CardsCount)
            {
                List<Card> cardsToDeal = deck.GetRange(0, Settings.CardsCount);
                deck.RemoveRange(0, Settings.CardsCount);

                // Log which cards are dealt to which player
                Debug.Log($"Dealing {string.Join(", ", cardsToDeal.Select(card => $"{card.CardRank} of {card.CardSuit}"))} to {player.Key} (Client ID: {player.Value})");

                // Serialize card data for transmission
                PlayerCardData cardData = new PlayerCardData
                {
                    PlayerID = player.Value,
                    Username = player.Key,
                    Cards = cardsToDeal.Select(card => new SimpleCard { Suit = card.CardSuit, Rank = card.CardRank }).ToList()
                };
                string message = JsonUtility.ToJson(cardData);

                // Send card data to each client
                Transport.OnHostSendMessageToClient(hostDriver, serverConnections, message, "deal-cards", player.Value);

                // Display cards for the host if the player is the host
                if (player.Key == username)
                {
                    Vector3 startPosition = new Vector3(-150, 0, 0); // Start position for the cards
                    foreach (var card in cardsToDeal)
                    {
                        CreateCard(cardPrefab, cardsParent, new SimpleCard { Suit = card.CardSuit, Rank = card.CardRank }, startPosition);
                        startPosition.x += 100; // Adjust this value based on your UI layout
                    }
                }
            }
        }
    }

    [Serializable]
    public class PlayerCardData
    {
        public int PlayerID;
        public string Username;
        public List<SimpleCard> Cards;
    }

    // Simple representation of a card for network transmission
    [Serializable]
    public struct SimpleCard
    {
        public Card.Suit Suit;
        public Card.Rank Rank;
    }

    [Serializable]
    public class CardData
    {
        public List<SimpleCard> Cards;
    }

    public void CreateCard(GameObject cardPrefab, Transform cardsParent, SimpleCard cardData, Vector3 position)
    {
        GameObject cardGO = Instantiate(cardPrefab, position, Quaternion.identity, cardsParent);
        DeckDisplayManager deckDisplayManager = FindObjectOfType<DeckDisplayManager>();
        if (deckDisplayManager != null)
        {
            // Assuming cardData.Suit and cardData.Rank are indices to the cardSprites array
            int spriteIndex = ((int)cardData.Suit * 13) + (int)cardData.Rank - 1;
            if (spriteIndex >= 0 && spriteIndex < deckDisplayManager.cardSprites.Length)
            {
                cardGO.GetComponent<Image>().sprite = deckDisplayManager.cardSprites[spriteIndex];
            }
            else
            {
                Debug.LogError("Invalid sprite index.");
            }
        }
        else
        {
            Debug.LogError("DeckDisplayManager not found in the scene.");
        }
    }
}
