using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DeckDisplayManager : MonoBehaviour
{
    public GameObject deckPrefab; // Prefab with an Image for the back of a deck
    public Transform deckParent; // Parent transform where decks will be instantiated
    public Sprite[] cardSprites; // Array of 52 card sprites, assigned in the inspector


    private List<List<Card>> decks = new List<List<Card>>();


    void Start()
    {

        //Button deckButton = deckPrefab.GetComponent<Button>();
        //if (deckButton != null)
        //{
        //    deckButton.onClick.AddListener(ShuffleAndDealCards);
        //}
        //else
        //{
        //    Debug.LogError("Deck prefab does not have a Button component attached.");
        //}

    }

    private void Update()
    {
        
    }



    // Call this method externally with the number of decks needed
    public void DisplayDecks(int count)
    {
        ClearDecks();
        InitializeDecks(count);
    }

    private void ClearDecks()
    {
        foreach (Transform child in deckParent)
        {
            Destroy(child.gameObject);
        }
        decks.Clear(); // Also clear the internal list of decks
    }

    private void InitializeDecks(int numberOfDecks)
    {
        for (int d = 0; d < numberOfDecks; d++)
        {
            List<Card> deck = new List<Card>();
            for (int i = 0; i < 52; i++)
            {
                deck.Add(new Card(i, cardSprites));
            }
            decks.Add(deck);
            CreateDeckVisual();

            // Debugging statement to log the count of cards
            Debug.Log($"Deck {d + 1} initialized with {deck.Count} cards.");
        }
    }

    private void CreateDeckVisual()
    {
        GameObject deckGO = Instantiate(deckPrefab, deckParent);
        //// Assign the click listener to deal cards when the deck (dummy card) is clicked
        //Button deckButton = deckGO.GetComponent<Button>();
        //if (deckButton != null)
        //{
        //    deckButton.onClick.AddListener(ShuffleAndDealCards);
        //}
        //else
        //{
        //    Debug.LogError("No Button component found on deck prefab!");
        //}
    }

    public void ShuffleAndDealCards()
    {
        // Assuming you're only dealing with one deck
        List<Card> deck = decks[0];

        // Shuffle the deck
        System.Random rng = new System.Random();
        int n = deck.Count;
        while (n > 1)
        {
            n--;
            int k = rng.Next(n + 1);
            Card value = deck[k];
            deck[k] = deck[n];
            deck[n] = value;
        }

        // Now the deck is shuffled, let the HostManager handle the distribution
        HostManager.Instance.DealCardsToPlayers(deck);
    }
}
