﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using Unity.Collections;
using Unity.Netcode;
using Unity.Networking.Transport;
using Unity.Networking.Transport.Relay;
using Unity.Services.Authentication;
using Unity.Services.Core;
using Unity.Services.Relay;
using Unity.Services.Relay.Models;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using NetworkEvent = Unity.Networking.Transport.NetworkEvent;

public class ClientManager : NetworkBehaviour
{
    public static ClientManager Instance { get; private set; }


    public TextMeshProUGUI status;
    public TextMeshProUGUI joinCodeText;
    public TextMeshProUGUI roomName;
    public Button nextButton;
    public Button exitButton;

    public GameObject cardPrefab; // Assign in the inspector
    public Transform cardsParent; // Assign in the inspector


    private string message = "";
    private string roomOwner = "";
    private string username = "";
    private string joincode = "";
    private int clientID = 0;

    NetworkDriver playerDriver;
    NetworkConnection clientConnection;

    DataHelper Helper = new DataHelper();
    PlayerManager PlayerManager;
    RoomManager RoomManager;

    #region Initialize Relay
    public void Start()
    {
        //if (Instance == null)
        //{
        //    Instance = this;
        //}
        //else
        //{
        //    Destroy(gameObject); // If there's already an instance, destroy this duplicate
        //    return;
        //}

        InitialSetup();

    
    }

    public void InitialSetup()
    {
        nextButton.interactable = false;
        status.text = "";
        joinCodeText.text = "";
        roomName.text = "";
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }
        InitialSetup();
    }

    public async Task Authenticate()
    {
        PlayerManager = GameObject.FindObjectOfType<PlayerManager>();
        RoomManager = GameObject.FindObjectOfType<RoomManager>();

        await UnityServices.InitializeAsync();


        AuthenticationService.Instance.SignedIn += () =>
        {
            Debug.Log("Signed In " + AuthenticationService.Instance.PlayerId);
        };


        await AuthenticationService.Instance.SignInAnonymouslyAsync();
        await SetupClient();
    }

    public async Task SetupClient()
    {
        try
        {
            JoinAllocation playerAllocation = await RelayService.Instance.JoinAllocationAsync(joincode);
            if (playerAllocation == null)
            {
                // Trigger alert for incorrect join code
                RoomManager.SendAlert("Invalid Join Code", "Please check the join code and try again.");
                return;
            }

            var relayServerData = new RelayServerData(playerAllocation, "udp");
            var settings = new NetworkSettings();
            settings.WithRelayParameters(ref relayServerData);

            // Create the Player's NetworkDriver from the NetworkSettings object.
            playerDriver = NetworkDriver.Create(settings);

            // Bind to the Relay server.
            if (playerDriver.Bind(NetworkEndPoint.AnyIpv4) != 0)
            {
                Debug.LogError("Player client failed to bind");

            }
            else
            {
                Debug.Log("Player client bound to Relay server");
            }

            clientConnection = playerDriver.Connect();
            roomName.text = roomOwner;
            message = "Status: " + username + " have joined the room";
            status.text = message;
            joinCodeText.text = "Join Code: " + joincode;
        }
        catch (RelayServiceException e)
        {
            if (e.Reason == RelayExceptionReason.InvalidRequest || e.Reason == RelayExceptionReason.JoinCodeNotFound)
            {

                RoomManager.SendAlert("Invalid Join Code", "Please check the Join Code and try again");
            }
            else if (e.Reason == RelayExceptionReason.AllocationNotFound)
            {
                RoomManager.SendAlert("Max Players Joined", "Room is Full!");
            }
            else
            {
                RoomManager.SendAlert("Error", "An unexpected error occurred, please try again later.\n" + e.Reason);
            }
        }
    }

    public override void OnDestroy()
    {
        playerDriver.Dispose();
    }

    #endregion

    #region Send Message
    public void OnPlayerSendMessage(string message, string type)
    {
        if (!clientConnection.IsCreated)
        {
            Debug.LogError("Player is not connected. No Host client to send message to.");
            return;
        }

        NetworkData data = new NetworkData
        {
            type = type,
            value = message
        };

        byte[] bytes = Helper.TransformDataToBytes(data);

        if (playerDriver.BeginSend(clientConnection, out var writer) == 0)
        {
            NativeArray<byte> nativeBytes = new NativeArray<byte>(bytes.Length, Allocator.Temp);
            nativeBytes.CopyFrom(bytes);

            // Write the NativeArray<byte> to the writer
            writer.WriteBytes(nativeBytes);

            // Release the NativeArray<byte>
            nativeBytes.Dispose();

            playerDriver.EndSend(writer);
        }
        Debug.Log("done");

    }
    #endregion

    #region Update
    void Update()
    {
        // Skip update logic if the Player is not yet bound.
        if (!playerDriver.IsCreated || !playerDriver.Bound)
        {
            return;
        }

        // This keeps the binding to the Relay server alive,
        // preventing it from timing out due to inactivity.
        playerDriver.ScheduleUpdate().Complete();

        // Resolve event queue.
        NetworkEvent.Type eventType;
        while ((eventType = clientConnection.PopEvent(playerDriver, out var stream)) != NetworkEvent.Type.Empty)
        {
            switch (eventType)
            {
                // Handle Relay events.
                case NetworkEvent.Type.Data:
                    HandleClientMessage(stream);
                    break;

                // Handle Connect events.
                case NetworkEvent.Type.Connect:
                    Debug.Log("Player connected to the Host");
                    OnPlayerSendMessage(username, "player-join");
                    break;

                // Handle Disconnect events.
                case NetworkEvent.Type.Disconnect:
                    Debug.Log("Player got disconnected from the Host");
                    RoomManager.SendAlert("Disconnected", "You got disconnected from the server");
                    clientConnection = default(NetworkConnection);
                    break;
            }
        }
    }
    #endregion

    public void SetData(string username, string joincode)
    {
        this.username = username;
        this.joincode = joincode;
    }

    void HandleClientMessage(DataStreamReader stream)
    {
        NetworkData receivedData = Helper.TransformDataToObject(stream);

        if (receivedData.type == "deal-cards")
        {
            Debug.Log($"Received cards: {receivedData.value}");
            PlayerCardData cardData = JsonUtility.FromJson<PlayerCardData>(receivedData.value);
            Debug.Log($"Received cards: {cardData}");
            // Debug.Log($"Checking card data for player ID {cardData.PlayerID} against client ID {clientID+1}");

            Debug.Log($"Instantiating cards for client {clientID}");
            Vector3 startPosition = new Vector3(1000, 190, 0); // This should now represent the final position for each card.
            foreach (var card in cardData.Cards)
            {
                // Directly instantiate cards at their final positions
                CreateCard(cardPrefab, cardsParent, card, startPosition);
                startPosition.x += 100; // Adjust this value based on your UI layout needs.
            }
        }

        else if (receivedData.type == "update-deck-count")
        {
            Debug.Log("Received deck count data: " + receivedData.value);
            if (int.TryParse(receivedData.value, out int deckCount))
            {
                Debug.Log("Parsed deck count: " + deckCount);
                var deckDisplayManager = FindObjectOfType<DeckDisplayManager>();
                if (deckDisplayManager != null)
                {
                    deckDisplayManager.DisplayDecks(deckCount);
                    Debug.Log("Decks displayed successfully");
                }
                else
                {
                    Debug.LogError("DeckDisplayManager not found on scene.");
                }
            }
            else
            {
                Debug.LogError("Failed to parse deck count from received data: " + receivedData.value);
            }
        }

        if (receivedData.type == "room-info")
        {
            Debug.Log($"Player received msg: {receivedData.value}");
            roomOwner = receivedData.value;
            roomName.text = roomOwner;
        }
        else if (receivedData.type == "status")
        {
            Debug.Log($"Player received msg: {receivedData.value}");
            message = receivedData.value;
            status.text = message;
        }

        else if (receivedData.type == "change-turn")
        {
            Debug.Log("Current player is : " + receivedData.value);
            if (receivedData.value == username)
            {
                Debug.Log("its your turn now");
                nextButton.interactable = true;
                //PlayerManager.StartTurn(clientID);
            }
        }

        else if (receivedData.type == "clientID")
        {
            Debug.Log($"Player received msg: {receivedData.value}");
            this.clientID = int.Parse(receivedData.value);
        }

        else if (receivedData.type == "player-manager-sync")
        {
            Debug.Log("Syncing Players\n" + receivedData.value);

            string[] playerInfoArray = receivedData.value.Split(';');
            Debug.Log("Array of Players count: " + playerInfoArray);
            // Convert the array to a list
            foreach (string clientString in playerInfoArray)
            {
                ClientJoinData client = JsonUtility.FromJson<ClientJoinData>(clientString);
                PlayerManager.SetUsername(int.Parse(client.clientId), client.username);
                PlayerManager.SetPlayerActive(int.Parse(client.clientId));
            }
        }

        else if (receivedData.type == "player-manager-arrange")
        {
            if (PlayerManager.IsEmpty())
            {
                PlayerManager.ArrangePlayers(int.Parse(receivedData.value), clientID);
            }
        }

        else if (receivedData.type == "player-manager-current-start")
        {
            PlayerManager.StartTurn(int.Parse(receivedData.value));
        }

        else if (receivedData.type == "player-manager-current-end")
        {
            PlayerManager.EndTurn(int.Parse(receivedData.value));
        }

        else if (receivedData.type == "exit")
        {
            exitButton.gameObject.SetActive(false);
            if (int.Parse(receivedData.value) == 1)
            {
                RoomManager.SendAlert("Game Over", "One Player have left the room\nGame Over!");
            }
            else
            {
                RoomManager.SendAlert("Game Over", "Host have left the room\nGame Over!");
            }
        }
    }

    public void SendExitNotice()
    {
        //destroy everything
        SceneManager.LoadScene("MainScene");
        playerDriver.Disconnect(clientConnection);
    }

    public void HandleClientTurn()
    {
        status.text = username + " made move";
        //PlayerManager.EndTurn(clientID);
        OnPlayerSendMessage(username, "made-move");
    }

    public void CreateCard(GameObject cardPrefab, Transform cardsParent, SimpleCard cardData, Vector3 position)
    {
        GameObject cardGO = Instantiate(cardPrefab, position, Quaternion.identity, cardsParent);
        DeckDisplayManager deckDisplayManager = FindObjectOfType<DeckDisplayManager>();
        if (deckDisplayManager != null)
        {
            // Assuming cardData.Suit and cardData.Rank are indices to the cardSprites array
            int spriteIndex = ((int)cardData.Suit * 13) + (int)cardData.Rank - 1;
            if (spriteIndex >= 0 && spriteIndex < deckDisplayManager.cardSprites.Length)
            {
                cardGO.GetComponent<Image>().sprite = deckDisplayManager.cardSprites[spriteIndex];
            }
            else
            {
                Debug.LogError("Invalid sprite index.");
            }
        }
        else
        {
            Debug.LogError("DeckDisplayManager not found in the scene.");
        }
    }

    // These classes must be defined in the ClientManager as well, to deserialize the data
    [Serializable]
    public struct SimpleCard
    {
        public Card.Suit Suit;
        public Card.Rank Rank;
    }

    [Serializable]
    public class PlayerCardData
    {
        public int PlayerID;
        public string Username;
        public List<SimpleCard> Cards;
    }
}

