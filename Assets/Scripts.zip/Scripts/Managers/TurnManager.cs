﻿using System.Collections.Generic;
using UnityEngine;

public class TurnManager
{

    public Dictionary<string, int> playerOrder = new Dictionary<string, int>(); // Username and corresponding turn order
    private int currentPlayerIndex = 0; // Index of the current player in the turn order
    private bool direction = true; //clockwise by default

    // Add players to the turn order
    public void AddPlayer(string playerName)
    {
        if (!playerOrder.ContainsKey(playerName))
        {
            playerOrder.Add(playerName, playerOrder.Count); // Assign turn order based on the order they join
        }
    }

    public void SetDirection(bool direction)
    {
        this.direction = direction;
    }

    // Get the name of the current player whose turn it is
    public string GetCurrentPlayer()
    {
        foreach (var entry in playerOrder)
        {
            if (entry.Value == currentPlayerIndex)
            {
                return entry.Key;
            }
        }
        return null;
    }

    public bool IsTurn(string username)
    {
        foreach (var entry in playerOrder)
        {
            if (entry.Key == username)
            {
                if (entry.Value == currentPlayerIndex)
                    return true;
            }
        }
        return false;
    }

    public int GetCount()
    {
        return playerOrder.Count;
    }

    // Move to the next player's turn
    public void NextTurn()
    {
        if (!direction)
        {
            currentPlayerIndex = (currentPlayerIndex + 1) % playerOrder.Count;
        }
        else
        {
            currentPlayerIndex--;
            if (currentPlayerIndex < 0)
            {
                currentPlayerIndex = playerOrder.Count - 1;
            }
        }
    }

    public int GetPlayerPosition(string username)
    {
        foreach (var entry in playerOrder)
        {
            if (entry.Key == username)
            {
                return entry.Value;
            }
        }
        return -1;
    }
}
