﻿using System;
public class GameState
{
    public GameState()
    {
    }
}
