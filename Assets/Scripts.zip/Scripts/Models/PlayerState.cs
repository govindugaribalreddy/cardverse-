﻿using System;
public class PlayerState
{
    public PlayerState()
    {
    }
}
