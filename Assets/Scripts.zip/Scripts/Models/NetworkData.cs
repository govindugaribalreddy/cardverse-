﻿[System.Serializable]
public class NetworkData
{
    public string type;
    public string value;
}

[System.Serializable]
public class ClientJoinData
{
    public string username;
    public string clientId;
}