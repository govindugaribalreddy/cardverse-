using TMPro;
using UnityEngine;

public class MainMenuActions : MonoBehaviour
{

    public static RelayManager RelayManager { get; set; }
    [SerializeField] private TMP_InputField username;
    [SerializeField] private TMP_InputField joincode;

    private void Start()
    {
        RelayManager = new RelayManager();
    }

    public void CreateRoom()
    {
        RelayManager.SetData(username.text, "");
        RelayManager.StartHost();
    }

    public void JoinRoom()
    {
        RelayManager.SetData(username.text, joincode.text);
        RelayManager.StartClient();
    }
}
