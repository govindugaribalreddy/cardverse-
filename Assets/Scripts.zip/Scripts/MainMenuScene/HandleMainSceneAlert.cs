using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class HandleMainSceneAlert : MonoBehaviour
{
    private static HandleMainSceneAlert instance;
    public GameObject alertPopupPrefab; // Reference to the prefab for the alert popup
    public GameObject Menu;
    public TMP_Text headingText; // Text component for heading
    public TMP_Text bodyText; // Text component for body

    void Start()
    {
        alertPopupPrefab.SetActive(false);
    }

    // Method to display the alert popup with specified heading and body text
    public void DisplayAlert(string heading, string body)
    {
        // Set the heading and body text
        headingText.text = heading;
        bodyText.text = body;

        // Make the alert popup visible
        alertPopupPrefab.SetActive(true);
        Menu.SetActive(false);
    }

    //only in Room Scene
    public void ExitConfirmation()
    {
        headingText.text = "Exit Game";
        bodyText.text = "Are you sure you want to exit this Game Room?";

        // Make the alert popup visible
        alertPopupPrefab.SetActive(true);
        Image closeButton = alertPopupPrefab.transform.Find("Close Popup").GetComponent<Image>();
        closeButton.gameObject.SetActive(true);
        Button exitButton = alertPopupPrefab.transform.Find("ExitGame").GetComponent<Button>();
        exitButton.gameObject.SetActive(true);
    }
}
