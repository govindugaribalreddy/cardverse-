using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.Netcode;
using UnityEngine;

public class MakeMove : MonoBehaviour
{
    void Start()
    {
    }

    public void makeMove()
    {
        Debug.Log("Attempting to make move");
        RoomManager manager = GameObject.FindObjectOfType<RoomManager>();
        manager.NextClick();
    }
    
}
